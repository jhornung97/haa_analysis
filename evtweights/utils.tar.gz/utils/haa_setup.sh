#source /cvmfs/cms.cern.ch/cmsset_default.sh
#cd $home/utils/CMSSW_14_1_0_pre4/src
#cmsenv  
#cd $home

SCRAM_ARCH=el7_amd64_gcc12
source /cvmfs/cms.cern.ch/cmsset_default.sh
cmsrel CMSSW_14_1_0_pre4
cd CMSSW_14_1_0_pre4/src
cmsenv  
cd $home