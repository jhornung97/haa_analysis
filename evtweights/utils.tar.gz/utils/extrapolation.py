import uproot
from concurrent.futures import ThreadPoolExecutor
import awkward as ak
import os
import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit
import mplhep as hep
import sys
import csv
import os
import json

sys.path.append('/work/jhornung/Haa/Scripts/')
import HistLib as hl
import utility as util

plt.style.use(hep.style.CMS)

def read_file(filename, data_type="data"):
    if data_type == "data":
        with uproot.open(filename) as file:
            tree = file["ntuple"]
            data = tree.arrays([
                "H_mass",
                "pt_vis",
                "m_vis",
                "H_eta",
                "d1_pt",
                "d2_pt",
                "ps_1_mass",
                "ps_2_mass",
                "d1_iso",
                "d2_iso"
            ])
            return data
    elif data_type == "mc":
        with uproot.open(filename) as file:
            tree = file["ntuple"]
            data = tree.arrays([
                "H_mass",
                "pt_vis",
                "m_vis",
                "H_eta",
                "d1_pt",
                "d2_pt",
                "ps_1_mass",
                "ps_2_mass",
                "d1_iso",
                "d2_iso",
                "id_wgt_mu_1",
                "id_wgt_mu_2",
                "iso_wgt_mu_1",
                "iso_wgt_mu_2",
                "trigger_wgt_mu_1",
                "trigger_wgt_mu_2",
                "evtweight",
                "puweight",
                "genWeight"
            ])
            return data
    
def model(x, a, x0, b):
    return a * (1 - np.exp(-x/x0)) ** b

def model_errors(x, a, x0, b, cov, withCorr=True):
    da = (1 - np.exp(-x/x0)) ** b
    dx0 = - a * b * x * (1 - np.exp(-x/x0)) ** (b - 1) * np.exp(-x/x0) / x0**2
    db = a * (1 - np.exp(-x/x0)) ** (b) * np.log(1 - np.exp(-x/x0) + 1e-12)

    diag_term = da**2 * cov[0,0] + dx0**2 * cov[1,1] + db**2 * cov[2,2]
    non_diag_terms = 2 * (da * cov[0,1] * dx0 + da * cov[0,2] * db + dx0 * cov[1,2] * db)
    if withCorr:
        return np.sqrt(diag_term + non_diag_terms)
    else:
        return np.sqrt(diag_term) 
    
year = sys.argv[1]
scope = sys.argv[2]

if scope == 'mm':
    path = f"/ceph/jhornung/Data_2018/{year}/single_muon_data/{scope}/"
    exclude = "single_muon_data.root"
elif scope == 'ee' and year == '2018':
    path = f"/ceph/jhornung/Data_2018/{year}/egamma_data/{scope}/"
    exclude = "egamma_data.root"
elif scope == 'ee' and (year == '2017' or year == '2016preVFP' or year == '2016postVFP'):
    path = f"/ceph/jhornung/Data_2018/{year}/single_electron_data/{scope}/"
    exclude = "single_electron_data.root"

filelist = [path + f for f in os.listdir(path) if f.endswith(".root") and f != exclude]

with ThreadPoolExecutor(max_workers=2) as executor:
    results = list(executor.map(read_file, filelist))

data = ak.concatenate(results)

H_mass_mask = ((data["H_mass"] > 70) & (data["H_mass"] < 110)) | ((data["H_mass"] > 140) & (data["H_mass"] < 200))
H_eta_mask = (np.abs(data["H_eta"]) < 2.4)
leading_k_mask = (data["d1_pt"] > 10) & (data["d2_pt"] > 10)
ps_mass_mask = (data["ps_1_mass"] < 3) & (data["ps_2_mass"] < 3) & (np.abs(data["ps_1_mass"] - data["ps_2_mass"]) < 0.06)
pt_vis_mask = (data["pt_vis"] > 30)
m_vis_mask = (data["m_vis"] > 75) & (data["m_vis"] < 105)
mask = H_mass_mask & H_eta_mask & leading_k_mask & ps_mass_mask & pt_vis_mask & m_vis_mask

counts = []
iso_cuts = []
threshold = 0.1
cut = 10
step = 0.5
continue_cutting = True

ref_hist, edges = np.histogram(data["H_mass"][mask], bins=65, range=(70, 200))
ref_bin_count = np.sum(ref_hist)

bin_centers = (edges[:-1] + edges[1:]) / 2

while continue_cutting:
    iso_mask = (data["d1_iso"] < cut) & (data["d2_iso"] < cut)
    hist, _ = np.histogram(data["H_mass"][mask & iso_mask], bins=65, range=(70, 200))
    efficiency = np.sum(hist) / ref_bin_count
    if efficiency < threshold:
        continue_cutting = False
    else:
        iso_cuts.append(cut)
        counts.append(np.sum(hist))
        cut -= step

iso_cuts = np.array(iso_cuts)
counts = np.array(counts)
error = np.sqrt(counts)

popt, pcov = curve_fit(model, iso_cuts, counts, sigma=error, p0=[ref_bin_count, 1, 1], absolute_sigma=True)

x_fit = np.linspace(0, 10.5, 2001)
y_fit = model(x_fit, *popt)
error_fit = model_errors(x_fit, *popt, pcov, withCorr=False)

extrapolated_value = model(0.5, *popt)
extrapolated_error = model_errors(0.5, *popt, pcov, withCorr=False)

result = {
    "normalization": extrapolated_value,
    "normalization_error": extrapolated_error
}

output_file = f"/work/jhornung/Haa/iso_extrapolation/bkg_normalization.json"

if os.path.exists(output_file):
    with open(output_file, 'r') as f:
        data = json.load(f)
else:
    data = {}

if year not in data:
    data[year] = {}
if scope not in data[year]:
    data[year][scope] = {}

data[year][scope] = result

#with open(output_file, 'w') as f:
#    json.dump(data, f, indent=2)

ratio = (counts - model(iso_cuts, *popt)) / model_errors(iso_cuts, *popt, pcov, withCorr=False)
ratio_errors = np.sqrt(error**2/model_errors(iso_cuts, *popt, pcov, withCorr=False)**2)

mc_loc = f"/ceph/jhornung/MC_2018/{year}"

if year == "2016preVFP":
        bkgs = [
                "DYJetsToLL_M-50_TuneCP5_13TeV-amcatnloFXFX-pythia8+RunIISummer20UL16MiniAODAPVv2-106X_mcRun2_asymptotic_preVFP_v11-v1+MINIAODSIM",
                "ttbar",
                "diboson",
                "wh",
                "single_top"
                #"qcd"
                ]
elif year == "2016postVFP":
        bkgs = [
                "DYJetsToLL_M-50_TuneCP5_13TeV-amcatnloFXFX-pythia8+RunIISummer20UL16MiniAODv2-106X_mcRun2_asymptotic_v17-v1+MINIAODSIM",
                "ttbar",
                "diboson",
                "wh",
                "single_top"
                #"qcd"
                ]
elif year == "2017":
        bkgs = [
                "DYJetsToLL_M-50_TuneCP5_13TeV-amcatnloFXFX-pythia8+RunIISummer20UL17MiniAODv2-106X_mc2017_realistic_v9-v2+MINIAODSIM",
                "ttbar",
                "diboson",
                "wh",
                "single_top"
                #"qcd"
                ]
elif year == "2018":
        bkgs = [
                "DYJetsToLL_M-50_TuneCP5_13TeV-amcatnloFXFX-pythia8+RunIISummer20UL18MiniAODv2-106X_upgrade2018_realistic_v16_L1v1-v2+MINIAODSIM",
                "ttbar",
                "diboson",
                "wh",
                "single_top"
                #"qcd"
                ]

bkg_labels = [
        'Drell-Yan', 
        r'$t\,\bar{t}$', 
        r'Diboson', 
        r'$W\,H\rightarrow \ell\,\nu\, b\,\bar{b}$', 
        r'Single Top'
        #r'QCD'
        ]

mc_bkg = hl.data(mc_loc, bkgs, bkg_labels, scope)
bkg_branches = mc_bkg.branches_dict
z_pt_weights = mc_bkg.get_Z_pt_weights()

mc_masks = {}
mc_weights = {}
mc_counts = {}

lumi = None
if year == "2016preVFP":
    lumi = 19.5
elif year == "2016postVFP":
    lumi = 16.8
elif year == "2017":
    lumi = 41.5
elif year == "2018":
    lumi = 59.8

for key, branch in bkg_branches.items():
    H_mass_mask = ((branch["H_mass"] > 70) & (branch["H_mass"] < 110)) | ((branch["H_mass"] > 140) & (branch["H_mass"] < 200))
    H_eta_mask = (np.abs(branch["H_eta"]) < 2.4)
    leading_k_mask = (branch["d1_pt"] > 10) & (branch["d2_pt"] > 10)
    ps_mass_mask = (branch["ps_1_mass"] < 3) & (branch["ps_2_mass"] < 3) & (np.abs(branch["ps_1_mass"] - branch["ps_2_mass"]) < 0.06)
    pt_vis_mask = (branch["pt_vis"] > 30)
    m_vis_mask = (branch["m_vis"] > 75) & (branch["m_vis"] < 105)
    mask = H_mass_mask & H_eta_mask & leading_k_mask & ps_mass_mask & pt_vis_mask & m_vis_mask
    mc_masks[key] = mask

    if scope == 'mm':
        trigger_sf = 1 - ((1 - branch["trigger_wgt_mu_1"]) * (1 - branch["trigger_wgt_mu_2"]))
        sfs = branch["id_wgt_mu_1"] * branch["id_wgt_mu_2"] * branch["iso_wgt_mu_1"] * branch["iso_wgt_mu_2"] * trigger_sf
    elif scope == 'ee':
        trigger_sf = 1 - ((1 - branch["trigger_wgt_ele_1"]) * (1 - branch["trigger_wgt_ele_2"]))
        sfs = branch["id_wgt_ele_1"] * branch["id_wgt_ele_2"] * trigger_sf
    signs = np.array(list(map(util.weights, branch["genWeight"])))
    if key == 'Drell-Yan':
        mc_weights[key] = lumi * 1e3 * sfs * signs * branch["evtweight"] * branch["puweight"] * z_pt_weights
    else:
        mc_weights[key] = lumi * 1e3 * sfs * signs * branch["evtweight"] * branch["puweight"]

    mc_count = []

    for iso_cut in iso_cuts:
        iso_mask = (branch["d1_iso"] < iso_cut) & (branch["d2_iso"] < iso_cut)
        hist, _ = np.histogram(branch["H_mass"][mask & iso_mask], weights=mc_weights[key][mask & iso_mask], bins=65, range=(70, 200))
        mc_count.append(np.sum(hist))

    mc_counts[key] = np.array(mc_count)

fig, axs = plt.subplots(2, 1, sharex=True, gridspec_kw={"height_ratios": [3, 1]})

iso_cuts_fill = np.insert(iso_cuts, 0, 10.5)
iso_cuts_fill = np.append(iso_cuts_fill, np.min(iso_cuts) - 0.5)

previous_counts = np.zeros_like(iso_cuts_fill) 

colors = ['seagreen', 'gold', 'darkorange', 'orange', 'mediumspringgreen']

for i, (key, mc_count) in enumerate(mc_counts.items()):
    mc_count = np.insert(mc_count, 0, 0)
    mc_count = np.append(mc_count, 0)
    axs[0].fill_between(iso_cuts_fill[::-1], previous_counts[::-1], previous_counts[::-1] + mc_count[::-1], step='mid', label=key, alpha=1, color=colors[i], linewidth=0)
    previous_counts += mc_count

axs[0].errorbar(iso_cuts, counts, yerr=error, fmt='o', color='black')
axs[0].plot(x_fit, y_fit, color='red', label='Fit')
axs[0].errorbar(0.5, model(0.5, *popt), yerr=model_errors(0.5, *popt, pcov, withCorr=True), fmt='o', color='red', label='Extrapolation')
axs[0].fill_between(x_fit, y_fit - error_fit, y_fit + error_fit, facecolor='red', alpha=0.25, label='Fit Error', linewidth=0)
axs[0].set_ylabel("Event yield", fontsize=20)
axs[0].set_xlim(0, 10.5)
axs[0].set_ylim(bottom=0, top=1.25 * max(counts))
axs[0].legend(loc='upper left', fontsize=17)
axs[0].set_title(r"$\it{" + "Private \: work" + "}$" +" "+ r"$\bf{" + "(CMS \: data/simulation)" + "}$",loc="left", fontsize=20)
if "2016" in year:
    axs[0].set_title(f"{lumi} fb$^{{-1}}$, 2016 (13 $\mathrm{{{{TeV}}}}$)",loc="right", fontsize=20)
else:
    axs[0].set_title(f"{lumi} fb$^{{-1}}$, {year} (13 $\mathrm{{{{TeV}}}}$)",loc="right", fontsize=20)

axs[1].errorbar(iso_cuts, ratio, yerr=ratio_errors, fmt='o', color='black')
axs[1].axhline(0, color='red', linestyle='--')
axs[1].fill_between(x_fit, -1, 1, color='red', alpha=0.25, linewidth=0)
axs[1].set_ylabel(r"$\frac{Data - Fit}{Fit\ Error}$", fontsize=20)
axs[1].set_xlabel("Isolation Cut", fontsize=20)
axs[1].set_xlim(0, 10.25)
axs[1].set_ylim(-3, 3)

plt.tight_layout()
fig.subplots_adjust(hspace=0)

plt.savefig(f"/web/jhornung/public_html/analysis_plots/{year}/{scope}_iso_cut_extrapolation.png")
plt.savefig(f"/web/jhornung/public_html/analysis_plots/{year}/{scope}_iso_cut_extrapolation.pdf")

plt.show()
