import sys
import ROOT
from ROOT import RooFit
import numpy as np
import os

scope = sys.argv[1]
year = sys.argv[2]
iso_mask = sys.argv[3] 

path = None 

if scope == "mm":
    path = f"/ceph/jhornung/Data_2018/{year}/single_muon_data/{scope}/"
    exclude = "single_muon_data.root"
    files = [path + f for f in os.listdir(path) if f.endswith(".root") and f != exclude]

    ROOT.ROOT.EnableImplicitMT(len(files))

    df = ROOT.RDataFrame("ntuple", files)

elif scope == "ee" and year == "2018":
    path = f"/ceph/jhornung/Data_2018/{year}/egamma_data/{scope}/"
    exclude = "egamma_data.root"
    files = [path + f for f in os.listdir(path) if f.endswith(".root") and f != exclude]
    
    ROOT.ROOT.EnableImplicitMT(len(files))

    df = ROOT.RDataFrame("ntuple", files)

elif scope == "ee" and (year == "2017" or year == "2016preVFP" or year == "2016postVFP"):
    path = f"/ceph/jhornung/Data_2018/{year}/single_electron_data/{scope}/"
    exclude = "single_electron_data.root"
    files = [path + f for f in os.listdir(path) if f.endswith(".root") and f != exclude]

    ROOT.ROOT.EnableImplicitMT(len(files))

    df = ROOT.RDataFrame("ntuple", files)
    
df = df.Define(f"H_mass_{year}_{scope}", "H_mass")
df = df.Define("nominal", "1")
df = df.Define("ps_mass_mask", "ps_1_mass < 3 && ps_2_mass < 3 && abs(ps_1_mass-ps_2_mass) < 0.06")
df = df.Define("iso_mask", f"d1_iso < {iso_mask} && d2_iso < {iso_mask}") # && d3_iso < {iso_mask} && d4_iso < {iso_mask}")
df = df.Define("mask", "pt_vis > 30 && (m_vis > 75 && m_vis < 105) && abs(H_eta) < 2.4 && d1_pt > 10 && d2_pt > 10 && ps_mass_mask && iso_mask")
snap = df.Snapshot("ntuple", f"bkg_{scope}.root")

f = ROOT.TFile.Open(f"bkg_{scope}.root")
t = f.Get("ntuple")

mass = ROOT.RooRealVar(f"H_mass_{year}_{scope}", "H_mass", 125, 70, 200)
mask = ROOT.RooRealVar("mask", "mask", 0, 1)
weight = ROOT.RooRealVar("nominal", "weight", -10, 10) 

data = ROOT.RooDataSet(f"data_H_mass_{year}_{scope}", "data", ROOT.RooArgSet(mass, mask), RooFit.Import(t),  RooFit.Cut("mask==1"))#, RooFit.WeightVar(weight))

print(data.sumEntries())

nbins = 65
binning = ROOT.RooFit.Binning(nbins, 70, 200)
mass.setRange("full", 70, 200)
mass.setRange("loSB", 70, 110)
mass.setRange("hiSB", 140, 200)
fitRange = "loSB,hiSB"

decorrelated_alpha = ROOT.RooRealVar(f"alpha_{year}_{scope}", "coeff of the exp func", -.02, -.025, -.015)
decorrelated_model_bkg = ROOT.RooExponential(f"model_bkg_mass_H_mass_{year}_{scope}", "exp func", mass, decorrelated_alpha)
decorrelated_result = decorrelated_model_bkg.fitTo(data, RooFit.Range(fitRange), RooFit.Save())

alpha_val = decorrelated_result.floatParsFinal().find(f"alpha_{year}_{scope}").getVal()
alpha_err = decorrelated_result.floatParsFinal().find(f"alpha_{year}_{scope}").getError()

print(f"Fitted alpha: {alpha_val} +/- {alpha_err}")

csv_path = f"/work/jhornung/Haa/alphas_{year}_{scope}.csv"
if not os.path.exists(csv_path):
    with open(csv_path, "w") as f:
        f.write(f"{iso_mask} {alpha_val} {alpha_err}\n")
else:
    with open(csv_path, "a") as f:
        f.write(f"{iso_mask} {alpha_val} {alpha_err}\n")