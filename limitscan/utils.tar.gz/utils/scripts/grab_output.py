import sys
import csv
import os
import uproot

iso_cut = sys.argv[1]
year = sys.argv[2]
home = sys.argv[3]

if not os.path.exists(f'/ceph/jhornung/iso_limitscan_{year}'):
    open(f'/ceph/jhornung/iso_limitscan_{year}', 'w').close() 

ifile = uproot.open(f'{home}/limits_{iso_cut}/{year}/combined/higgsCombine.limits_iso_cut_{iso_cut}.AsymptoticLimits.mH125.root')
branches = ifile['limit'].arrays()
if len(branches['quantileExpected']) == 5:
    expected = branches['limit'][branches['quantileExpected'] == 0.5][0]
else:
    expected = -1

with open(f'/ceph/jhornung/iso_limitscan_{year}', 'a') as f:
    writer = csv.writer(f, delimiter=' ')
    writer.writerow([iso_cut, expected])